#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>
#include <SDL_image.h>
#include <pthread.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>
#include "jeu.h"
#include "constantes.h"


typedef struct{
int **carte1;
SDL_Surface* ecran1;
}listearg;

listearg liste;
// creation de score
double compteurbombelink = 0;
double compteurbombelinkdark = 0;
double destructionRocherlink=0;
double destructionRocherlinkdark=0;
double ratiolink=1;
double ratiolinkdark=1;

// SDL_Surface -- Graphical Surface Structure
// SDL_Surface's represent areas of "graphical" memory, memory that can be drawn to
SDL_Surface *texte=NULL;
SDL_Surface *textedark=NULL;
TTF_Font *police=NULL;
SDL_Color couleurNoire={0,0,0}, couleurOr={255,215,0};
char score[20]="";
char scoredark[20]="";

///////////////////////

// ! SDL_Rect -- Defines a rectangular area : x, y	Position of the upper-left corner of the rectangle

SDL_Rect positionbomberouge;

SDL_Rect positionbombe;
SDL_Rect positionbombedroit;
SDL_Rect positionbombegauche;
SDL_Rect positionbombebas;
SDL_Rect positionbombehaut;
SDL_Rect positionbombecentre;


// position des winners
SDL_Rect positionlinkwin;
SDL_Rect positionlinkdarkwin;






void updateClavier(Touches* etat_clavier){ // ce fonction nous permet d'appuier sur deux touches simultanes
SDL_Event event;
    while(SDL_PollEvent(&event)){ // SDL_PollEvent() donne le code de la touche presse

        switch(event.type){
        case SDL_KEYDOWN: etat_clavier->key[event.key.keysym.sym]=1; break;// si une touche on envoie  1
        case SDL_KEYUP:etat_clavier->key[event.key.keysym.sym]=0; break; // la touche est relache on envoie 0
        default:break;
        }

    }

}

// position de rectangle
SDL_Rect position , positionJoueur;
SDL_Rect positiondark , positionJoueurdark;

int commencer;



void jouer(SDL_Surface* ecran){

Touches etat_clavier;
memset(&etat_clavier,0,sizeof(etat_clavier)); //initialiser toutes les cases du etat clavier a 0

SDL_Surface *linkwin=NULL; // pour afficher les images des joueurs qui gagne
SDL_Surface *linkwindark=NULL;
// tableau qui va contenir les 4 images (bas , haut , ..)
SDL_Surface *link[4]={NULL};
SDL_Surface *linkd[4]={NULL};



// links
SDL_Surface *linkActuel =NULL;
SDL_Surface *linkdarkActuel=NULL;
SDL_Surface *mur=NULL;
SDL_Surface *rock=NULL;

SDL_Surface *bombe=NULL;
SDL_Surface *blackbombe=NULL;
SDL_Surface *bomberouge=NULL;

SDL_Surface *bombedroit=NULL;
SDL_Surface *bombegauche=NULL;
SDL_Surface *bombebas=NULL;
SDL_Surface *bombehaut=NULL;
SDL_Surface *bombecentre=NULL;


SDL_Surface *bombeblackdroit=NULL;
SDL_Surface *bombeblackgauche=NULL;
SDL_Surface *bombeblackbas=NULL;
SDL_Surface *bombeblackhaut=NULL;
SDL_Surface *bombeblackcentre=NULL;


SDL_Event event;
commencer=1;
int i,j=0;
// creation du map
int **carte=(int**)malloc(11*sizeof(int*));
for(i=0;i<11;i++){
carte[i]=(int*)malloc(26*sizeof(int));
}
{
carte[0][0]=0;
 carte[0][1]=0;
 carte[0][2]=0;
 carte[0][3]=0;
 carte[0][4]=0;
 carte[0][5]=0;
 carte[0][6]=0;
 carte[0][7]=0;
 carte[0][8]=0;
 carte[0][9]=0;
 carte[0][10]=0;
 carte[0][11]=0;
 carte[0][12]=0;
 carte[0][13]=0;
 carte[0][14]=0;
 carte[0][15]=0;
 carte[0][16]=0;
 carte[0][17]=0;
 carte[0][18]=0;
 carte[0][19]=0;
 carte[0][20]=0;
 carte[0][21]=0;
 carte[0][22]=0;
 carte[0][23]=0;
 carte[0][24]=0;
 carte[0][25]=0;
 carte[1][0]=0;
 carte[1][1]=0;
 carte[1][2]=0;
 carte[1][3]=0;
 carte[1][4]=0;
 carte[1][5]=0;
 carte[1][6]=0;
 carte[1][7]=0;
 carte[1][8]=0;
 carte[1][9]=0;
 carte[1][10]=0;
 carte[1][11]=0;
 carte[1][12]=0;
 carte[1][13]=0;
 carte[1][14]=0;
 carte[1][15]=0;
 carte[1][16]=0;
 carte[1][17]=0;
 carte[1][18]=0;
 carte[1][19]=0;
 carte[1][20]=0;
 carte[1][21]=0;
 carte[1][22]=0;
 carte[1][23]=0;
 carte[1][24]=0;
 carte[1][25]=0;
 carte[2][0]=0;
 carte[2][1]=0;
 carte[2][2]=1;
 carte[2][3]=1;
 carte[2][4]=1;
 carte[2][5]=1;
 carte[2][6]=1;
 carte[2][7]=1;
 carte[2][8]=1;
 carte[2][9]=1;
 carte[2][10]=1;
 carte[2][11]=1;
 carte[2][12]=1;
 carte[2][13]=1;
 carte[2][14]=1;
 carte[2][15]=1;
 carte[2][16]=1;
 carte[2][17]=1;
 carte[2][18]=1;
 carte[2][19]=1;
 carte[2][20]=1;
 carte[2][21]=1;
 carte[2][22]=1;
 carte[2][23]=1;
 carte[2][24]=1;
 carte[2][25]=1;
 carte[3][0]=0;
 carte[3][1]=0;
 carte[3][2]=1;
 carte[3][3]=0;
 carte[3][4]=0;
 carte[3][5]=0;
 carte[3][6]=0;
 carte[3][7]=0;
 carte[3][8]=0;
 carte[3][9]=0;
 carte[3][10]=0;
 carte[3][11]=0;
 carte[3][12]=0;
 carte[3][13]=0;
 carte[3][14]=0;
 carte[3][15]=0;
 carte[3][16]=0;
 carte[3][17]=0;
 carte[3][18]=0;
 carte[3][19]=0;
 carte[3][20]=0;
 carte[3][21]=0;
 carte[3][22]=0;
 carte[3][23]=0;
 carte[3][24]=0;
 carte[3][25]=1;
 carte[4][0]=0;
 carte[4][1]=0;
 carte[4][2]=1;
 carte[4][3]=0;
 carte[4][4]=0;
 carte[4][5]=1;
 carte[4][6]=0;
 carte[4][7]=1;
 carte[4][8]=0;
 carte[4][9]=0;
 carte[4][10]=0;
 carte[4][11]=0;
 carte[4][12]=0;
 carte[4][13]=1;
 carte[4][14]=0;
 carte[4][15]=0;
 carte[4][16]=1;
 carte[4][17]=1;
 carte[4][18]=0;
 carte[4][19]=0;
 carte[4][20]=0;
 carte[4][21]=0;
 carte[4][22]=0;
 carte[4][23]=1;
 carte[4][24]=0;
 carte[4][25]=1;
 carte[5][0]=0;
 carte[5][1]=0;
 carte[5][2]=1;
 carte[5][3]=0;
 carte[5][4]=1;
 carte[5][5]=0;
 carte[5][6]=0;
 carte[5][7]=0;
 carte[5][8]=1;
 carte[5][9]=0;
 carte[5][10]=1;
 carte[5][11]=0;
 carte[5][12]=1;
 carte[5][13]=0;
 carte[5][14]=0;
 carte[5][15]=0;
 carte[5][16]=0;
 carte[5][17]=0;
 carte[5][18]=0;
 carte[5][19]=1;
 carte[5][20]=1;
 carte[5][21]=0;
 carte[5][22]=1;
 carte[5][23]=1;
 carte[5][24]=0;
 carte[5][25]=1;
 carte[5][25]=1;
 carte[6][0]=0;
 carte[6][1]=999;
 carte[6][2]=0;
 carte[6][3]=0;
 carte[6][4]=1;
 carte[6][5]=0;
 carte[6][6]=0;
 carte[6][7]=1;
 carte[6][8]=0;
 carte[6][9]=1;
 carte[6][10]=1;
 carte[6][11]=0;
 carte[6][12]=1;
 carte[6][13]=0;
 carte[6][14]=0;
 carte[6][15]=0;
 carte[6][16]=1;
 carte[6][17]=1;
 carte[6][18]=0;
 carte[6][19]=1;
 carte[6][20]=0;
 carte[6][21]=1;
 carte[6][22]=0;
 carte[6][23]=1;
 carte[6][24]=0;
 carte[6][25]=0;
 carte[7][0]=0;
 carte[7][1]=0;
 carte[7][2]=1;
 carte[7][3]=0;
 carte[7][4]=1;
 carte[7][5]=0;
 carte[7][6]=0;
 carte[7][7]=1;
 carte[7][8]=0;
 carte[7][9]=0;
 carte[7][10]=1;
 carte[7][11]=0;
 carte[7][12]=0;
 carte[7][13]=0;
 carte[7][14]=1;
 carte[7][15]=0;
 carte[7][16]=0;
 carte[7][17]=0;
 carte[7][18]=0;
 carte[7][19]=1;
 carte[7][20]=0;
 carte[7][21]=0;
 carte[7][22]=0;
 carte[7][23]=1;
 carte[7][24]=0;
 carte[7][25]=1;
 carte[8][0]=0;
 carte[8][1]=0;
 carte[8][2]=1;
 carte[8][3]=0;
 carte[8][4]=1;
 carte[8][5]=1;
 carte[8][6]=0;
 carte[8][7]=1;
 carte[8][8]=0;
 carte[8][9]=0;
 carte[8][10]=1;
 carte[8][11]=0;
 carte[8][12]=1;
 carte[8][13]=1;
 carte[8][14]=1;
 carte[8][15]=0;
 carte[8][16]=1;
 carte[8][17]=1;
 carte[8][18]=0;
 carte[8][19]=1;
 carte[8][20]=0;
 carte[8][21]=0;
 carte[8][22]=0;
 carte[8][23]=1;
 carte[8][24]=0;
 carte[8][25]=1;
 carte[9][0]=0;
 carte[9][1]=0;
 carte[9][2]=1;
 carte[9][3]=0;
 carte[9][4]=0;
 carte[9][5]=0;
 carte[9][6]=0;
 carte[9][7]=0;
 carte[9][8]=0;
 carte[9][9]=0;
 carte[9][10]=0;
 carte[9][11]=0;
 carte[9][12]=0;
 carte[9][13]=0;
 carte[9][14]=0;
 carte[9][15]=0;
 carte[9][16]=0;
 carte[9][17]=0;
 carte[9][18]=0;
 carte[9][19]=0;
 carte[9][20]=0;
 carte[9][21]=0;
 carte[9][22]=0;
 carte[9][23]=0;
 carte[9][24]=0;
 carte[9][25]=1;
 carte[10][0]=0;
 carte[10][1]=0;
 carte[10][2]=1;
 carte[10][3]=1;
 carte[10][4]=1;
 carte[10][5]=1;
 carte[10][6]=1;
 carte[10][7]=1;
 carte[10][8]=1;
 carte[10][9]=1;
 carte[10][10]=1;
 carte[10][11]=1;
 carte[10][12]=1;
 carte[10][13]=1;
 carte[10][14]=1;
 carte[10][15]=1;
 carte[10][16]=1;
 carte[10][17]=1;
 carte[10][18]=1;
 carte[10][19]=1;
 carte[10][20]=1;
 carte[10][21]=1;
 carte[10][22]=1;
 carte[10][23]=1;
 carte[10][24]=1;
 carte[10][25]=1;
}

{

linkwin=IMG_Load("white_winner.bmp");
linkwindark=IMG_Load("black_winner.bmp");

mur=IMG_Load("mur.bmp");
rock=IMG_Load("rock.bmp");

bombe=IMG_Load("bomb.bmp");
bomberouge=IMG_Load("red_bomb.bmp");

blackbombe=IMG_Load("blackbombe.bmp");

bombehaut=IMG_Load("fire_up.bmp");
bombebas=IMG_Load("fire_down.bmp");
bombegauche=IMG_Load("fire_left.bmp");
bombedroit=IMG_Load("fire_right.bmp");
bombecentre=IMG_Load("fire_center.bmp");


link[BAS]=IMG_Load("down.bmp");
link[HAUT]=IMG_Load("up.bmp");
link[GAUCHE]=IMG_Load("left.bmp");
link[DROITE]=IMG_Load("right.bmp");

linkd[BAS]=IMG_Load("down_black.bmp");
linkd[HAUT]=IMG_Load("up_black.bmp");
linkd[GAUCHE]=IMG_Load("left_black.bmp");
linkd[DROITE]=IMG_Load("right_black.bmp");

}

linkActuel=link[BAS];
linkdarkActuel=linkd[BAS];


positionJoueur.x=3;
positionJoueur.y=3;

carte[3][3]=LINK; // placement du joueur

positionJoueurdark.x=5;
positionJoueurdark.y=3;

carte[3][5]=LINKD;

placement_aleatoire_rock(carte);

SDL_EnableKeyRepeat(100,100); //speed

    while(commencer==1){
     // tant que commencer =1 jouer
     {
        updateClavier(&etat_clavier); // on envoie les 0

        if(etat_clavier.key[SDLK_ESCAPE]) commencer=0;

        if(etat_clavier.key[SDLK_UP]){ // if le code de key appuie est fleche up
        linkActuel=link[HAUT];
        deplacerJoueur(carte,&positionJoueur,HAUT);
        }
        if(etat_clavier.key[SDLK_DOWN]){
        linkActuel=link[BAS];
        deplacerJoueur(carte,&positionJoueur,BAS);
        }
        if(etat_clavier.key[SDLK_RIGHT]){
        linkActuel=link[DROITE];
        deplacerJoueur(carte,&positionJoueur,DROITE);
        }
        if(etat_clavier.key[SDLK_LEFT]){
        linkActuel=link[GAUCHE];
        deplacerJoueur(carte,&positionJoueur,GAUCHE);
        }

        // creation du bombe
        if(etat_clavier.key[SDLK_m]){
        creation_bombe(carte,ecran);
        }
        // creation du bombe black
        if(etat_clavier.key[SDLK_b]){
        creation_bombeDARK(carte,ecran);
        }

         if(etat_clavier.key[SDLK_z]){
        linkdarkActuel=linkd[HAUT];
        deplacerJoueur(carte,&positionJoueurdark,HAUT);
        }
        if(etat_clavier.key[SDLK_s]){
        linkdarkActuel=linkd[BAS];
        deplacerJoueur(carte,&positionJoueurdark,BAS);
        }
        if(etat_clavier.key[SDLK_d]){
        linkdarkActuel=linkd[DROITE];
        deplacerJoueur(carte,&positionJoueurdark,DROITE);
        }
        if(etat_clavier.key[SDLK_q]){
        linkdarkActuel=linkd[GAUCHE];
        deplacerJoueur(carte,&positionJoueurdark,GAUCHE);
        }
    }

// SDL_FillRect -- This function performs a fast fill of the given rectangle with some color
// int SDL_FillRect(SDL_Surface *dst, SDL_Rect *dstrect, Uint32 color);
SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format,255,255,255));

//creation du map
for (i=0;i<11;i++){
   for (j=0;j<26;j++){
    position.x=j*TAILLE_BLOC;
    position.y=i*TAILLE_BLOC;
    int rand_monster;
        switch(carte[i][j]){
            case MUR: SDL_BlitSurface(mur,NULL,ecran,&position); break;  // SDL_BlitSurface -- This performs a fast blit from the source surface to the destination surface
            case ROCK: SDL_BlitSurface(rock,NULL,ecran,&position); break; // int SDL_BlitSurface(SDL_Surface *src, SDL_Rect *srcrect, SDL_Surface *dst, SDL_Rect *dstrect);
            case BOMBE: SDL_BlitSurface(bombe,NULL,ecran,&position); break;
            case BLACKBOMBE: SDL_BlitSurface(blackbombe,NULL,ecran,&position); break;
            case BOMBEROUGE: SDL_BlitSurface(bomberouge,NULL,ecran,&position); break;

            case BOMBECENTRE: SDL_BlitSurface(bombecentre,NULL,ecran,&position); break;
            case BOMBEDROIT: SDL_BlitSurface(bombedroit,NULL,ecran,&position); break;
            case BOMBEGAUCHE: SDL_BlitSurface(bombegauche,NULL,ecran,&position); break;
            case BOMBEHAUT: SDL_BlitSurface(bombehaut,NULL,ecran,&position); break;
            case BOMBEBAS: SDL_BlitSurface(bombebas,NULL,ecran,&position); break;

        }
   }
}
position.x=positionJoueur.x*TAILLE_BLOC;
position.y=positionJoueur.y*TAILLE_BLOC;
SDL_BlitSurface(linkActuel,NULL,ecran,&position); // placer le joueur sur l 'ecran (charger l'image)

positiondark.x=positionJoueurdark.x*TAILLE_BLOC;
positiondark.y=positionJoueurdark.y*TAILLE_BLOC;
SDL_BlitSurface(linkdarkActuel,NULL,ecran,&positiondark);


usleep(80000); // diminuer la vitesse


// position de score
if(TTF_Init() == -1)
{
    fprintf(stderr, "Erreur d'initialisation de TTF_Init : %s\n", TTF_GetError());
    exit(EXIT_FAILURE);
}

// initialiser ttf

police=TTF_OpenFont("Triforce.ttf",26);
sprintf(score,"%.2f :LINK", ratiolink); // sprintf nous permet d'afficher le score sur l'ecran
sprintf(scoredark,"%.2f :LINK", ratiolinkdark);
texte=TTF_RenderText_Blended(police,score,couleurOr);
textedark=TTF_RenderText_Blended(police,scoredark,couleurOr);


position.x=200;
position.y=3;
SDL_BlitSurface(texte,NULL,ecran,&position);
SDL_Flip(ecran);


position.x=600;
position.y=3;
SDL_BlitSurface(textedark,NULL,ecran,&position);
/////////////
SDL_Flip(ecran);

}

// quitter

if(commencer==5){
Mix_CloseAudio();
Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);
Mix_Music *gagner;
gagner=Mix_LoadMUS("victory.mp3");
Mix_PlayMusic(gagner,0);
positionlinkwin.x=300;
SDL_BlitSurface(linkwin,NULL,ecran,&positionlinkwin);
SDL_Flip(ecran);
sleep(8);
commencer=0;
}

if(commencer==6){
Mix_CloseAudio();
Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);
Mix_Music *gagner;
gagner=Mix_LoadMUS("victory.mp3");
Mix_PlayMusic(gagner,0);
positionlinkdarkwin.x=300;
//positionlinkdarkwin.y=number;

SDL_BlitSurface(linkwindark,NULL,ecran,&positionlinkwin);
SDL_Flip(ecran);
sleep(8);
commencer=0;
}


SDL_FreeSurface(mur);
SDL_FreeSurface(rock);



for (i=0 ; i<4 ; i++){
SDL_FreeSurface(link[i]);
}

for (i=0 ; i<4 ; i++){
SDL_FreeSurface(linkd[i]);
}

SDL_FreeSurface(bombe);
SDL_FreeSurface(bombecentre);
SDL_FreeSurface(bombegauche);
SDL_FreeSurface(bombedroit);
SDL_FreeSurface(bombebas);
SDL_FreeSurface(bombehaut);
SDL_FreeSurface(bomberouge);

SDL_FreeSurface(linkwin);
SDL_FreeSurface(linkwindark);

SDL_FreeSurface(texte);
SDL_FreeSurface(textedark);

}


void deplacerJoueur(int **carte, SDL_Rect *pos , int direction){
    switch(direction){
        case HAUT: if(carte[pos->y-1][pos->x]==MUR || carte[pos->y-1][pos->x]==ROCK) break; pos->y--; break;
        case BAS: if(carte[pos->y+1][pos->x]==MUR || carte[pos->y+1][pos->x]==ROCK) break; pos->y++; break;
        case GAUCHE: if(positionJoueur.x==2 && positionJoueur.y==6)
                            //si le joueur se trouve a la deuxieme colonne et a la 6 ligne et on a appuie sur gauche
                            //alors le joueur se teleporte a la colonne 25
                     { if (carte[6][25]==ROCK) break; else {positionJoueur.x=25 ; positionJoueur.y=6 ; break; } }
                     if(positionJoueurdark.x==2 && positionJoueurdark.y==6)
                            //si le joueur se trouve a la deuxieme colonne et a la 6 ligne et on a appuie sur gauche
                            //alors le joueur se teleporte a la colonne 25
                     { if (carte[6][25]==ROCK) break; else {positionJoueurdark.x=25 ; positionJoueurdark.y=6 ; break; } }
                    if(carte[pos->y][pos->x-1]==MUR || carte[pos->y][pos->x-1]==ROCK) break; pos->x--; break;
        case DROITE: if(positionJoueur.x==25 && positionJoueur.y==6)
                        { if (carte[6][2]==ROCK) break; else {positionJoueur.x=2 ; positionJoueur.y=6 ; break;} }
                     if(positionJoueurdark.x==25 && positionJoueurdark.y==6)
                     { if (carte[6][2]==ROCK) break; else {positionJoueurdark.x=2 ; positionJoueurdark.y=6 ; break;} }
                     if(carte[pos->y][pos->x+1]==MUR || carte[pos->y][pos->x+1]==ROCK) break; pos->x++; break;


}
}

void placement_aleatoire_rock(int **carte){
int i=0, j=0;
for(i=3;i<11;i++){
        srand(time(NULL)); // to generate a new random number every time
    for(j=2;j<27;j++){
        if(carte[i][j]==VIDE && carte[i][j] != LINK){
            int v=rand()%3;
            if (v==0) {carte[i][j]=ROCK;}
        }
    }
}
for(i=3;i<11;i++){ // the player must not be surrounded by rocks and cannot move
    for(j=2;j<27;j++){
        if (carte[i][j]==LINK){
            if(carte[i+1][j]==ROCK) carte[i+1][j]=VIDE;
            if(carte[i-1][j]==ROCK) carte[i-1][j]=VIDE;
            if(carte[i][j+1]==ROCK) carte[i][j+1]=VIDE;
            if(carte[i][j-1]==ROCK) carte[i][j-1]=VIDE;

        }
    }
}
}






void creation_bombe(int **carte,SDL_Surface* ecran){
pthread_t   thread1;
liste.carte1=carte;
liste.ecran1=ecran;
pthread_create(&thread1,NULL,gestion_bombe,(void*)&liste);
}


void gestion_bombe(void *arg){

int fin;
listearg *args=(listearg*)arg;
int **carte1=args->carte1;
int a,b=0;
for (a=2;a<11;a++){
    for(b=2;b<26;b++){
        if(carte1[a][b]==BOMBE || carte1[a][b]==BOMBEROUGE){pthread_exit(NULL);} // restriction de mettre plus qu'une bombe a la fois
    }
}

carte1[positionJoueur.y][positionJoueur.x]=BOMBE;

if(carte1[positionJoueur.y][positionJoueur.x]==BOMBE){
compteurbombelink++;  // augmenter le compteur  des bombes
}


usleep(200000); // la bombe va exploder dans une seconde
Mix_AllocateChannels(32);
Mix_Chunk *bruitbombe;
bruitbombe=Mix_LoadWAV("Explosion+1.mp3");
printf(bruitbombe);
Mix_PlayChannel(2,bruitbombe,0);

for (a=2;a<11;a++){ // augmenter le compteur des rock
    for(b=2;b<26;b++){
        if(carte1[a][b]==BOMBE){
            if(carte1[a][b-1]==ROCK)    { destructionRocherlink=destructionRocherlink+1; }
            if(carte1[a][b+1]==ROCK)    { destructionRocherlink=destructionRocherlink+1; }
            if(carte1[a-1][b]==ROCK)    { destructionRocherlink=destructionRocherlink+1; }
            if(carte1[a+1][b]==ROCK)    { destructionRocherlink=destructionRocherlink+1; }
        }
    }
}

for (a=2;a<11;a++){
    for(b=2;b<26;b++){
    if(carte1[a][b]==BOMBE){
    carte1[a][b]=BOMBEROUGE; // transformer la bombe bleu par une bombe rouge (animation)
    usleep(200000);
     carte1[a][b]=BOMBE;
    usleep(200000);
     carte1[a][b]=BOMBEROUGE;
    usleep(200000);
     carte1[a][b]=BOMBE;
    usleep(200000);
    }

    }
}

for (a=2;a<11;a++){
    for(b=2;b<26;b++){
        if(carte1[a][b]==BOMBE){
        carte1[a][b]=BOMBECENTRE;

         if(carte1[a][b]==carte1[positionJoueur.y][positionJoueur.x]){
            fin=2;
            }

        if(carte1[a][b]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
        fin=1;
        }


            if(carte1[a+1][b]!=MUR){
            carte1[a+1][b]=BOMBEBAS;
            }
            if(carte1[a+1][b]==carte1[positionJoueur.y][positionJoueur.x]){
            carte1[a+1][b]=BOMBEBAS;
            fin=2;
            }
            if(carte1[a+1][b]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
            carte1[a+1][b]=BOMBEBAS;
            fin=1;
            }
            if(carte1[a+1][b]==ROCK){
            carte1[a+1][b]=BOMBEBAS;
            }
            ////////////////////////////////////////

             if(carte1[a-1][b]!=MUR){
            carte1[a-1][b]=BOMBEHAUT;
            }
            if(carte1[a-1][b]==carte1[positionJoueur.y][positionJoueur.x]){
            carte1[a-1][b]=BOMBEHAUT;
            fin=2;
            }
            if(carte1[a-1][b]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
            carte1[a-1][b]=BOMBEHAUT;
            fin=1;
            }
            if(carte1[a-1][b]==ROCK){
            carte1[a-1][b]=BOMBEHAUT;
            }

             ////////////////////////////////////////

             if(carte1[a][b-1]!=MUR){
            carte1[a][b-1]=BOMBEGAUCHE;
            }
            if(carte1[a][b-1]==carte1[positionJoueur.y][positionJoueur.x]){
            carte1[a][b-1]=BOMBEGAUCHE;
            fin=2;
            }
            if(carte1[a][b-1]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
            carte1[a][b-1]=BOMBEGAUCHE;
            fin=1;
            }
            if(carte1[a][b-1]==ROCK){
            carte1[a][b-1]=BOMBEGAUCHE;
            }

            ////////////////////////////////////////

             if(carte1[a][b+1]!=MUR){
            carte1[a][b+1]=BOMBEDROIT;
            }
            if(carte1[a][b+1]==carte1[positionJoueur.y][positionJoueur.x]){
            carte1[a][b+1]=BOMBEDROIT;
            fin=2;
            }
            if(carte1[a][b+1]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
            carte1[a][b+1]=BOMBEDROIT;
            fin=1;
            }
            if(carte1[a][b+1]==ROCK){
            carte1[a][b+1]=BOMBEDROIT;
            }


    }
}

}



usleep(200000);


ratiolink=destructionRocherlink/compteurbombelink;
sprintf(score,"%.2f :LINK", ratiolink);
texte=TTF_RenderText_Blended(police,score,couleurOr);

printf("this is the ratio link  %d \n", ratiolink);
printf("this is destruction rocher white %d \n",destructionRocherlink);
printf("this is the compteur bombe link  %d \n",compteurbombelink);

for(a=2;a<11;a++){
    for(b=2;b<26;b++){

        if(carte1[a][b]==BOMBECENTRE) {carte1[a][b]=VIDE;}
        if(carte1[a][b]==BOMBEBAS) {carte1[a][b]=VIDE;}
        if(carte1[a][b]==BOMBEDROIT) {carte1[a][b]=VIDE;}
        if(carte1[a][b]==BOMBEGAUCHE) {carte1[a][b]=VIDE;}
        if(carte1[a][b]==BOMBEHAUT) {carte1[a][b]=VIDE;}

    }
}

int vraie=1;
for(a=2;a<11;a++){
    for(b=2;b<26;b++){

        if(carte1[a][b]==ROCK) {vraie=0; break;}


    }
}

if (vraie) {if (ratiolink > ratiolinkdark) commencer=5;}
if(fin==1){commencer=5;}
if(fin==2){commencer=6;}

pthread_exit(NULL);


}


void gestion_bombeDRAK(void *arg){

int fin;
listearg *args=(listearg*)arg;
int **carte1=args->carte1;
int a,b=0;
for (a=2;a<11;a++){
    for(b=2;b<26;b++){
        if(carte1[a][b]==BLACKBOMBE || carte1[a][b]==BOMBEROUGE){pthread_exit(NULL);} // restriction de mettre plus qu'une bombe a la fois
    }
}

carte1[positionJoueurdark.y][positionJoueurdark.x]=BLACKBOMBE;


if(carte1[positionJoueurdark.y][positionJoueurdark.x]==BLACKBOMBE){
compteurbombelinkdark++;  // augmenter le compteur  des bombes
}

usleep(200000); // la bombe va exploder dans une seconde
Mix_AllocateChannels(32);
Mix_Chunk *bruitbombe;
bruitbombe=Mix_LoadWAV("Explosion+1.mp3");
printf(bruitbombe);
Mix_PlayChannel(2,bruitbombe,0);

for (a=2;a<11;a++){ // augmenter le compteur des rock
    for(b=2;b<26;b++){
        if(carte1[a][b]==BLACKBOMBE){
            if(carte1[a][b-1]==ROCK){destructionRocherlinkdark=destructionRocherlinkdark+1;}
            if(carte1[a][b+1]==ROCK){destructionRocherlinkdark=destructionRocherlinkdark+1;}
            if(carte1[a-1][b]==ROCK){destructionRocherlinkdark=destructionRocherlinkdark+1;}
            if(carte1[a+1][b]==ROCK){ destructionRocherlinkdark=destructionRocherlinkdark+1;}

                printf("this is the if statement in the black gestion rocher black %d \n",destructionRocherlinkdark);
        }
    }
}

for (a=2;a<11;a++){
    for(b=2;b<26;b++){
    if(carte1[a][b]==BLACKBOMBE){
    carte1[a][b]=BOMBEROUGE; // transformer la bombe bleu par une bombe rouge (animation)
    usleep(200000);
     carte1[a][b]=BLACKBOMBE;
    usleep(200000);
     carte1[a][b]=BOMBEROUGE;
    usleep(200000);
     carte1[a][b]=BLACKBOMBE;
    usleep(200000);
    }

    }
}

for (a=2;a<11;a++){
    for(b=2;b<26;b++){
        if(carte1[a][b]==BLACKBOMBE){
        carte1[a][b]=BOMBECENTRE;

         if(carte1[a][b]==carte1[positionJoueur.y][positionJoueur.x]){
            fin=2;
            }

        if(carte1[a][b]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
        fin=1;
        }


            if(carte1[a+1][b]!=MUR){
            carte1[a+1][b]=BOMBEBAS;
            }
            if(carte1[a+1][b]==carte1[positionJoueur.y][positionJoueur.x]){
            carte1[a+1][b]=BOMBEBAS;
            fin=2;
            }
            if(carte1[a+1][b]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
            carte1[a+1][b]=BOMBEBAS;
            fin=1;
            }
            if(carte1[a+1][b]==ROCK){
            carte1[a+1][b]=BOMBEBAS;
            }
            ////////////////////////////////////////

             if(carte1[a-1][b]!=MUR){
            carte1[a-1][b]=BOMBEHAUT;
            }
            if(carte1[a-1][b]==carte1[positionJoueur.y][positionJoueur.x]){
            carte1[a-1][b]=BOMBEHAUT;
            fin=2;
            }
            if(carte1[a-1][b]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
            carte1[a-1][b]=BOMBEHAUT;
            fin=1;
            }
            if(carte1[a-1][b]==ROCK){
            carte1[a-1][b]=BOMBEHAUT;
            }

             ////////////////////////////////////////

             if(carte1[a][b-1]!=MUR){
            carte1[a][b-1]=BOMBEGAUCHE;
            }
            if(carte1[a][b-1]==carte1[positionJoueur.y][positionJoueur.x]){
            carte1[a][b-1]=BOMBEGAUCHE;
            fin=2;
            }
            if(carte1[a][b-1]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
            carte1[a][b-1]=BOMBEGAUCHE;
            fin=1;
            }
            if(carte1[a][b-1]==ROCK){
            carte1[a][b-1]=BOMBEGAUCHE;
            }

            ////////////////////////////////////////

             if(carte1[a][b+1]!=MUR){
            carte1[a][b+1]=BOMBEDROIT;
            }
            if(carte1[a][b+1]==carte1[positionJoueur.y][positionJoueur.x]){
            carte1[a][b+1]=BOMBEDROIT;
            fin=2;
            }
            if(carte1[a][b+1]==carte1[positionJoueurdark.y][positionJoueurdark.x]){
            carte1[a][b+1]=BOMBEDROIT;
            fin=1;
            }
            if(carte1[a][b+1]==ROCK){
            carte1[a][b+1]=BOMBEDROIT;
            }


    }
}

}



usleep(200000);


ratiolinkdark=destructionRocherlinkdark/compteurbombelinkdark;

sprintf(score,"%.2f :LINK", ratiolinkdark);
texte=TTF_RenderText_Blended(police,score,couleurOr);

printf("this is the ratio link dark %d \n", ratiolinkdark);
printf("this is destruction rocher dark %d \n",destructionRocherlinkdark);
printf("this is the compteur bombe link dark %d \n",compteurbombelinkdark);

for(a=2;a<11;a++){
    for(b=2;b<26;b++){

        if(carte1[a][b]==BOMBECENTRE) {carte1[a][b]=VIDE;}
        if(carte1[a][b]==BOMBEBAS) {carte1[a][b]=VIDE;}
        if(carte1[a][b]==BOMBEDROIT) {carte1[a][b]=VIDE;}
        if(carte1[a][b]==BOMBEGAUCHE) {carte1[a][b]=VIDE;}
        if(carte1[a][b]==BOMBEHAUT) {carte1[a][b]=VIDE;}

    }
}


int vraiedark=1;
for(a=2;a<11;a++){
    for(b=2;b<26;b++){

        if(carte1[a][b]==ROCK) {vraiedark=0; break;}


    }
}

if(vraiedark) {if (ratiolink > ratiolinkdark) commencer=5;}

if(fin==1){commencer=5;}
if(fin==2){commencer=6;}

pthread_exit(NULL);


}


void creation_bombeDARK(int **carte,SDL_Surface* ecran){
pthread_t   thread2;
liste.carte1=carte;
liste.ecran1=ecran;
pthread_create(&thread2,NULL,gestion_bombeDRAK,(void*)&liste);
}








