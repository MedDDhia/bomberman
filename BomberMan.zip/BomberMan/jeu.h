#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED

typedef struct{
int key[SDLK_LAST];
}Touches;

void jouer(SDL_Surface* ecran);
void deplacerJoueur(int **carte, SDL_Rect *pos , int direction);
void placement_aleatoire_rock(int **carte);
void updateClavier(Touches* etat_clavier);
void creation_bombe(int **carte,SDL_Surface* ecran);
void gestion_bombe(void *arg);
#endif // JEU_H_INCLUDED
