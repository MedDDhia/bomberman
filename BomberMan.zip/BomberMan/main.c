#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include "fgifsdl.h"


int keyHit(){
SDL_Event e;
if(SDL_PollEvent(&e))
if(e.type==SDL_KEYDOWN)
return 1;
return 0;

}

int main(int argc , char * argv[]){

// create menu
SDL_Surface *ecran = NULL;
//SDL_Surface * menu=NULL;

// creation de gif
SDL_Gif* triforce;
SDL_Surface* tmp;
SDL_Rect positionTriforce;

SDL_Gif* press;
SDL_Rect positionPress;


//position de gif
positionTriforce.x=-234;
positionTriforce.y=0;

positionPress.x=409;
positionPress.y=0;




// ouvrir le systeme video (apparaitre les images , les videos)
SDL_Init(SDL_INIT_VIDEO);

SDL_WM_SetIcon(IMG_Load("front.bmp"), NULL);
// regler la taille de jeu video
ecran=SDL_SetVideoMode(952,442,32,SDL_HWSURFACE | SDL_DOUBLEBUF);

// donner le nom
SDL_WM_SetCaption("TIC_C BOMBER",NULL);


//charger le gif

triforce=SDLLoadGif("triforce.gif");
press=SDLLoadGif("pressakey.gif");

while(!keyHit()){
SDL_FillRect(ecran,NULL,SDL_MapRGB(ecran->format,255,255,255));
tmp=SDLGifAutoFrame(triforce); //jouer le gif
SDL_BlitSurface(tmp,NULL,ecran,&positionTriforce);
tmp=SDLGifAutoFrame(press);
SDL_BlitSurface(tmp,NULL,ecran,&positionPress);
SDL_Flip(ecran);
}

// charger la menu
//menu=IMG_Load("menu.png");

// donner les coordonnes de position de menu
//positionMenu.x=0;
//positionMenu.y=0;

// commencer a jouer
int commencer=3;
SDL_Event event; //evenement pour commencer le jeu

while(commencer){
SDL_WaitEvent(&event);
jouer(ecran);

    // reagir sur la click du button
    switch(event.type){

        case SDL_QUIT:  commencer=0; break ;

        case SDL_KEYDOWN :

            switch(event.key.keysym.sym){

                case SDLK_ESCAPE:commencer=0; break;
                //case SDLK_j: jouer(ecran) ; break;

                //case SDLK_KP1: printf("1 is pressed on joue");jouer(ecran) ; break;

            }

        break;

    }

// refrechir les images tant que la boucle while tourne
//SDL_BlitSurface(menu, NULL, ecran , &positionMenu);
SDL_Flip(ecran);

}

// quitter
//SDL_FreeSurface(menu);
SDLFreeGif(triforce);
SDLFreeGif(press);
SDL_Quit();
return EXIT_SUCCESS;

}
