#ifndef CONSTANTES_H_INCLUDED
#define CONSTANTES_H_INCLUDED

#define TAILLE_BLOC 34



// direction du joueur
enum{   HAUT , BAS , GAUCHE , DROITE};


//le joueur peu marcher dans le vide # mur
// link : image de joueur (joueur)
enum { VIDE , MUR , LINK , ROCK , LINKD , BOMBE , BLACKBOMBE , BOMBEROUGE, BOMBECENTRE , BOMBEBAS , BOMBEHAUT ,BOMBEDROIT, BOMBEGAUCHE };


#endif // CONSTANTES_H_INCLUDED
